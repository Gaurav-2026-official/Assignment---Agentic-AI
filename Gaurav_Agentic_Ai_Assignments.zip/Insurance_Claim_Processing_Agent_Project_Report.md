# AI Insurance Claim Processing Agent Using LangGraph

## Project Report

**Project:** AI-Powered Insurance Claim Processing Agent  
**Technology:** Python, LangGraph, LangChain, Ollama, Streamlit, Pydantic  
**LLM:** Ollama – Llama 3.2 3B  
**Application Type:** Local AI / Agentic AI Workflow  
**Human-in-the-Loop:** Yes  
**Document Processing:** PDF/TXT  
**Decision Engine:** Deterministic Python rules  
**Report Version:** 1.0

---

# 1. Executive Summary

Insurance claim processing is traditionally a multi-step workflow involving document verification, policy validation, fraud screening, claim assessment, summarization, and final approval. These steps can be time-consuming when performed manually and can create delays for both insurers and policyholders.

This project implements an **AI-powered Insurance Claim Processing Agent using LangGraph**. The application accepts structured claim details and supporting documents, executes multiple verification activities, summarizes the claim, and determines whether the claim should be automatically approved, rejected, or escalated for human review.

The solution is designed as an agentic workflow rather than a single LLM prompt. LangGraph is used to model the workflow as a stateful graph with multiple nodes, conditional routing, parallel processing, and Human-in-the-Loop intervention.

The implemented workflow contains the following major agents/nodes:

1. Document Verification Agent
2. Eligibility Check Agent
3. Fraud Detection Agent
4. Claim Summary Agent
5. Human Approval Agent

The first three checks can execute independently and are therefore represented as parallel branches in the LangGraph workflow. Their results are then combined before claim summarization and decision routing.

A key design decision is that **the final insurance decision is not delegated to the LLM**. Deterministic Python rules control approval, rejection, and escalation. The LLM is primarily used for generating a natural-language claim summary. This approach improves reliability and makes the system easier to test and explain.

The application also implements LangGraph's `interrupt()` mechanism for Human-in-the-Loop processing. High-value or high-risk claims can pause the graph and wait for a reviewer to approve or reject the claim through the Streamlit interface.

The final solution demonstrates how traditional business rules and generative AI can be combined into a controlled agentic workflow.

---

# 2. Problem Statement

Insurance companies receive claims accompanied by policy documents, identity documents, bills, invoices, police reports, travel documents, and other evidence.

A simplified traditional process may look like:

```text
Claim Received
      |
      v
Document Verification
      |
      v
Policy Eligibility
      |
      v
Fraud Screening
      |
      v
Claim Assessment
      |
      v
Manual Review
      |
      v
Approval / Rejection
```

The manual process introduces several challenges:

- Large volumes of claims
- Repetitive document verification
- Delays in processing
- Human effort for straightforward claims
- Difficulty maintaining consistent screening rules
- Need for escalation of suspicious or complex cases
- Risk of missing important information
- Difficulty creating standardized claim summaries

The objective of this project is to create an intelligent workflow that automates routine checks while retaining human control over exceptional cases.

---

# 3. Project Objectives

The primary objectives are:

- Build an AI-powered insurance claim processing application.
- Use LangGraph to orchestrate multiple processing agents.
- Verify required claim documents.
- Check policy eligibility.
- Detect configurable fraud indicators.
- Generate a concise claim summary.
- Automatically approve straightforward claims.
- Reject claims that clearly fail mandatory requirements.
- Escalate suspicious or high-value claims.
- Implement Human-in-the-Loop approval.
- Provide a Streamlit user interface.
- Keep the final business decision deterministic and explainable.
- Support local execution using Ollama instead of requiring a paid API.

---

# 4. Functional Requirements

The application accepts the following claim information:

- Claim ID
- Policy Number
- Claimant Name
- Claim Type
- Incident Date
- Policy Start Date
- Policy End Date
- Claim Amount
- Policy Limit
- Coverage Type
- Incident Description

The application also accepts supporting documents.

Supported document types include PDF and TXT files.

The workflow must perform:

### 4.1 Document Verification

Determine whether all required documents for the selected claim type have been provided.

Examples:

**Motor**
- Policy Document
- Identity Proof
- Repair Estimate / Invoice

**Health**
- Policy Document
- Identity Proof
- Medical Bills

**Travel**
- Policy Document
- Identity Proof
- Travel Tickets / Booking

**Property**
- Policy Document
- Identity Proof
- Damage Estimate / Invoice

**Theft**
- Policy Document
- Identity Proof
- Police Report

---

### 4.2 Eligibility Check

The system validates:

- Incident date against policy start date.
- Incident date against policy end date.
- Claim amount greater than zero.
- Claim amount within policy limit.

---

### 4.3 Fraud Detection

The system checks configurable risk indicators such as:

- Very high claim amount.
- Claim amount close to policy limit.
- Suspicious round-number claim amount.
- Incident close to policy expiry.
- Duplicate uploaded filenames.
- Text containing terms such as "amended", "altered", or "edited".

Fraud detection is treated as a screening mechanism and not as a definitive legal fraud determination.

---

### 4.4 Claim Summary

The application creates a concise natural-language summary containing:

- Claimant
- Claim type
- Incident date
- Claim amount
- Policy limit
- Document status
- Eligibility status
- Fraud screening result

The LLM is used for natural-language summarization.

---

### 4.5 Decision

The final decision can be:

- `AUTO_APPROVE`
- `REJECT`
- `HUMAN_REVIEW`

The final status can become:

- `APPROVED`
- `REJECTED`

For human-review cases, the final status depends on the reviewer's action.

---

# 5. Technology Stack

## 5.1 Python

Python is used as the primary programming language.

Reasons:

- Large AI ecosystem
- Excellent support for LangChain and LangGraph
- Easy document processing
- Strong data-processing capabilities
- Simple Streamlit integration

---

## 5.2 LangGraph

LangGraph is used to represent the claim workflow as a stateful graph.

It provides:

- Nodes
- Edges
- Conditional routing
- Shared state
- Parallel branches
- Checkpointing
- Human-in-the-Loop interruption and resumption

---

## 5.3 LangChain

LangChain provides integration between the application and the local LLM.

It is used for:

- LLM invocation
- Prompt handling
- Structured output
- Ollama integration

---

## 5.4 Ollama

Ollama provides local LLM execution.

The project uses:

```text
llama3.2:3b
```

Advantages:

- No OpenAI API key required
- No API credit required
- Local execution
- Better privacy for demonstration data
- Easy development and testing

---

## 5.5 Streamlit

Streamlit provides the web interface.

The UI allows the user to:

- Enter claim information
- Upload documents
- Start processing
- View workflow results
- Review human-approval cases
- Approve or reject escalated claims

---

## 5.6 Pydantic

Pydantic provides strongly typed data models.

It is used for:

- Claim input
- Document check
- Eligibility check
- Fraud check
- Claim summary
- Graph state

---

## 5.7 PyPDF

PyPDF/PyPDFLoader is used to extract text from PDF documents.

---

# 6. High-Level Architecture

The architecture can be represented as:

```text
                    +----------------------+
                    |     Streamlit UI     |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |    Claim Input       |
                    | + Supporting Docs    |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |    LangGraph State   |
                    +----------+-----------+
                               |
             +-----------------+-----------------+
             |                 |                 |
             v                 v                 v
     +---------------+ +---------------+ +---------------+
     | Document      | | Eligibility  | | Fraud         |
     | Verification  | | Check        | | Detection     |
     +-------+-------+ +-------+-------+ +-------+-------+
             |                 |                 |
             +-----------------+-----------------+
                               |
                               v
                    +----------------------+
                    |   Claim Summary      |
                    |       Agent          |
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    |   Decision Router     |
                    +----------+-----------+
                               |
                +--------------+--------------+
                |                             |
                v                             v
        +---------------+             +---------------+
        | Final Status  |             | Human Approval|
        |               |             | Agent         |
        +---------------+             +-------+-------+
                                                |
                                                v
                                        +---------------+
                                        | Final Status  |
                                        +---------------+
```

---

# 7. LangGraph Workflow Design

The core graph is implemented using LangGraph `StateGraph`.

The main nodes are:

```text
document_verification
eligibility_check
fraud_detection
claim_summary
decision_router
human_approval
final_status
```

The workflow begins with three independent checks.

Conceptually:

```text
START
 |\
 | \
 |  \
 v   v   v
DOC ELIG FRAUD
 |   |    |
 +---+----+
      |
      v
   SUMMARY
      |
      v
 DECISION ROUTER
    /       \
   /         \
REVIEW      NORMAL
  |            |
  v            v
HUMAN       FINAL
  |
  v
FINAL
```

This architecture demonstrates parallel execution of the three independent verification activities.

---

# 8. Shared Graph State

LangGraph uses a shared state object to transfer information between nodes.

The state contains fields such as:

```python
class ClaimState(TypedDict, total=False):
    claim: ClaimInput
    documents: list
    model: str
    document_check: DocumentCheck
    eligibility_check: EligibilityCheck
    fraud_check: FraudCheck
    claim_summary: ClaimSummary
    decision: str
    decision_reason: str
    human_approval: str
    human_comment: str
    final_status: str
```

This approach allows each node to update only the information it owns.

For example:

```text
Document Agent
      |
      +--> document_check

Eligibility Agent
      |
      +--> eligibility_check

Fraud Agent
      |
      +--> fraud_check
```

Later nodes consume those results.

---

# 9. Document Verification Agent

The Document Verification Agent identifies the documents required for the selected claim type.

Example:

```text
Claim Type = Motor
```

Required documents:

```text
Policy Document
Identity Proof
Repair Estimate / Invoice
```

The uploaded filenames are matched against configurable aliases.

Examples:

```text
policy_document.pdf
identity_proof.pdf
repair_invoice.pdf
```

can be mapped to:

```text
Policy Document
Identity Proof
Repair Estimate / Invoice
```

The result contains:

- Required documents
- Received documents
- Missing documents
- Verification status
- Notes

Example successful result:

```json
{
  "required_documents": [
    "Policy Document",
    "Identity Proof",
    "Repair Estimate / Invoice"
  ],
  "received_documents": [
    "Policy Document",
    "Identity Proof",
    "Repair Estimate / Invoice"
  ],
  "missing_documents": [],
  "verified": true
}
```

If a required document is missing, the claim becomes a rejection candidate.

---

# 10. Eligibility Check Agent

The Eligibility Agent applies deterministic policy rules.

The following conditions are evaluated.

## 10.1 Incident Before Policy Start

If:

```text
Incident Date < Policy Start Date
```

the claim is ineligible.

---

## 10.2 Incident After Policy Expiry

If:

```text
Incident Date > Policy End Date
```

the claim is ineligible.

---

## 10.3 Invalid Claim Amount

If:

```text
Claim Amount <= 0
```

the claim is rejected.

---

## 10.4 Claim Exceeds Policy Limit

If:

```text
Claim Amount > Policy Limit
```

the claim is ineligible.

Example:

```text
Claim Amount = ₹12,00,000
Policy Limit = ₹10,00,000
```

Result:

```text
ELIGIBLE = FALSE
```

The eligibility result is deterministic and therefore reproducible.

---

# 11. Fraud Detection Agent

Fraud detection is implemented as a rule-based screening mechanism.

The objective is not to declare that a claimant committed fraud.

Instead, the agent identifies potential risk indicators that should influence routing.

Example indicators:

### High Claim Amount

```text
Claim Amount >= ₹10,00,000
```

### Claim Close to Policy Limit

```text
Claim Amount >= 80% of Policy Limit
```

### Large Round Amount

```text
Claim Amount % 100000 == 0
```

### Incident Near Expiry

```text
Incident within 15 days of policy expiry
```

### Duplicate Filenames

Duplicate uploaded document names may be treated as a screening signal.

### Suspicious Text

The system checks for terms such as:

```text
amended
altered
edited
```

---

# 12. Fraud Risk Classification

The configured rules generate:

```text
LOW
MEDIUM
HIGH
```

Example:

```text
0 indicators -> LOW
1 indicator  -> MEDIUM
2+ indicators -> HIGH
```

An additional high-value rule can force higher scrutiny.

The system intentionally keeps these rules transparent.

This is important in financial and insurance workflows because reviewers should be able to understand why a claim was escalated.

---

# 13. Claim Summary Agent

The Claim Summary Agent creates a concise natural-language summary.

Example:

> Aarav Mehta has submitted a motor claim for an incident that occurred on 2026-09-10. The claim amount is ₹2,50,000, which is within the policy limit of ₹10,00,000. All required documents have been received and verified, and the policy appears eligible based on the supplied claim details. No strong fraud indicators were identified.

The LLM receives the structured facts rather than being asked to independently investigate the claim.

This limits hallucination risk.

---

# 14. Why the LLM Does Not Control the Final Decision

A major design principle in this project is separation of:

```text
Generative AI
```

from:

```text
Critical business decision
```

The LLM is useful for:

- Natural-language summaries
- Explanation
- Human-readable output

However, the final decision is controlled by deterministic Python rules.

This prevents the type of issue that can occur when an LLM directly generates a numeric or business-critical decision.

For example, the system does not ask:

```text
"Give this claim an approval score from 0 to 100."
```

and then trust the model.

Instead:

```text
Documents
Eligibility
Fraud
Claim Amount
        |
        v
Python Decision Engine
        |
        v
Decision
```

This makes the workflow deterministic.

---

# 15. Decision Engine

The decision logic follows this order.

## Rule 1 — Missing Documents

```text
if documents_missing:
    REJECT
```

## Rule 2 — Eligibility Failure

```text
if not eligible:
    REJECT
```

## Rule 3 — High Fraud Risk

```text
if fraud_risk == HIGH:
    HUMAN_REVIEW
```

## Rule 4 — High-Value Claim

```text
if claim_amount >= ₹10,00,000:
    HUMAN_REVIEW
```

## Rule 5 — Otherwise

```text
AUTO_APPROVE
```

This hierarchy ensures mandatory failures are handled before approval.

---

# 16. Conditional Routing

LangGraph conditional edges route claims based on the decision.

Conceptually:

```text
Claim Summary
     |
     v
Decision Router
     |
     +---- HUMAN_REVIEW ----> Human Approval
     |
     +---- AUTO_APPROVE ----> Final Status
     |
     +---- REJECT ----------> Final Status
```

This demonstrates a major LangGraph capability: workflow behavior changes based on state.

---

# 17. Human-in-the-Loop

Human-in-the-Loop is implemented using LangGraph's `interrupt()` mechanism.

When a claim requires human review, the workflow pauses.

The reviewer receives:

- Claim ID
- Claim amount
- Decision reason
- Document status
- Eligibility status
- Fraud risk
- Claim summary

The Streamlit application provides:

```text
[ Approve Claim ]    [ Reject Claim ]
```

The reviewer can also enter a comment.

The graph then resumes using a command containing the reviewer's decision.

This demonstrates true workflow interruption and resumption rather than simply displaying a message.

---

# 18. Why Human-in-the-Loop Is Important

Insurance decisions can involve financial, legal, and customer-impacting consequences.

A fully autonomous system could make inappropriate decisions in unusual cases.

Human review provides a safety mechanism for:

- High-value claims
- High-risk claims
- Ambiguous evidence
- Potential fraud
- Exceptions to standard policy rules

The project therefore follows a hybrid approach:

```text
Routine claim
     |
     v
Automation
```

and:

```text
Complex claim
     |
     v
AI Screening
     |
     v
Human Decision
```

---

# 19. Streamlit User Interface

The Streamlit application contains the following sections.

## Claim Information

Fields include:

- Claim ID
- Policy Number
- Claimant Name
- Claim Type
- Incident Date
- Policy Start Date
- Policy End Date
- Claim Amount
- Policy Limit
- Coverage Type
- Incident Description

## Supporting Documents

The user uploads PDF/TXT files.

## Processing

A button starts the LangGraph workflow:

```text
Process Insurance Claim
```

## Results

The application displays:

- Final status
- Document verification
- Eligibility
- Fraud risk
- Claim summary
- Decision
- Decision reason

## Human Review

Escalated claims display an approval panel.

---

# 20. Local Deployment

The application was designed to run locally.

Recommended project location:

```text
C:\AIInsurance
```

A short path is recommended on Windows because Python packages can contain deeply nested files and may exceed Windows path-length limitations in deeply nested project folders.

Virtual environment:

```text
C:\AIInsurance\.venv
```

---

# 21. Installation

Create the environment:

```powershell
cd C:\AIInsurance
py -3.10 -m venv .venv
```

Install dependencies:

```powershell
.\.venv\Scripts\python.exe -m pip install --upgrade pip
```

Then:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

No activation is required.

This approach avoids PowerShell execution-policy problems associated with:

```text
Activate.ps1
```

---

# 22. Ollama Setup

Install Ollama and obtain the model:

```powershell
ollama pull llama3.2:3b
```

Verify:

```powershell
ollama list
```

Expected model:

```text
llama3.2:3b
```

The application uses the local model through LangChain's Ollama integration.

---

# 23. Running the Application

From:

```text
C:\AIInsurance
```

run:

```powershell
.\.venv\Scripts\python.exe -m streamlit run app.py
```

Streamlit normally opens:

```text
http://localhost:8501
```

The browser provides the claim-processing interface.

---

# 24. Test Case 1 — Complete Valid Claim

### Input

```text
Claim ID: CLM-1001
Policy Number: POL-1001
Claimant: Aarav Mehta
Claim Type: Motor
Incident Date: 10/09/2026
Policy Start: 01/01/2026
Policy End: 31/12/2026
Claim Amount: ₹2,50,000
Policy Limit: ₹10,00,000
Coverage: Comprehensive
```

Documents:

```text
policy_document.pdf
identity_proof.pdf
repair_invoice.pdf
```

### Expected

```text
Documents       = VERIFIED
Eligibility     = ELIGIBLE
Fraud Risk      = LOW
Decision        = AUTO_APPROVE
Final Status    = APPROVED
```

### Actual Test Result

The application successfully produced:

```text
CLAIM APPROVED

Documents: Verified
Eligibility: Eligible
Fraud Risk: LOW
Decision: AUTO_APPROVE
```

This confirms the normal workflow.

---

# 25. Test Case 2 — Missing Document

Use the same Motor claim but upload:

```text
policy_document.pdf
identity_proof.pdf
```

Do not upload:

```text
repair_invoice.pdf
```

Expected:

```text
Document Verification = FAILED
Decision = REJECT
Final Status = REJECTED
```

Reason:

```text
Required document missing
```

This demonstrates that the system does not approve an incomplete claim.

---

# 26. Test Case 3 — Suspicious High-Value Claim

Use:

```text
Claim Amount = ₹12,00,000
Policy Limit = ₹15,00,000
```

Keep the policy dates valid and provide all required documents.

Expected:

```text
Documents = VERIFIED
Eligibility = ELIGIBLE
Fraud Risk = MEDIUM/HIGH
Decision = HUMAN_REVIEW
```

The workflow should pause at the Human Approval Agent.

The reviewer then chooses:

```text
APPROVE
```

or:

```text
REJECT
```

---

# 27. Test Case 4 — Expired Policy

Example:

```text
Incident Date = 15/01/2027
Policy End = 31/12/2026
```

Expected:

```text
Eligibility = INELIGIBLE
Decision = REJECT
Final Status = REJECTED
```

This demonstrates deterministic policy validation.

---

# 28. Test Case 5 — High-Value Valid Claim

Use:

```text
Claim Amount = ₹10,00,000
Policy Limit = ₹20,00,000
```

with valid dates and complete documents.

Expected:

```text
Documents = VERIFIED
Eligibility = ELIGIBLE
Decision = HUMAN_REVIEW
```

The claim is not automatically rejected because it is eligible.

Instead, its high value triggers additional human oversight.

---

# 29. Test Results Summary

| Test | Scenario | Expected | Result |
|---|---|---|---|
| 1 | Complete valid claim | Auto Approve | PASS |
| 2 | Missing document | Reject | PASS |
| 3 | Suspicious ₹12L claim | Human Review | PASS |
| 4 | Expired policy | Reject | PASS |
| 5 | High-value valid claim | Human Review | PASS |

The tests demonstrate that the workflow handles normal, invalid, suspicious, and high-value scenarios.

---

# 30. Reliability Design

One of the most important lessons from the implementation is that LLMs should not be responsible for deterministic business rules when predictable behavior is required.

The project therefore uses:

```text
Python Rules
```

for:

- Document completeness
- Eligibility
- Fraud indicators
- Final decision

and:

```text
LLM
```

for:

- Natural-language claim summary

This separation improves reliability.

---

# 31. Handling LLM Failure

The claim summary is useful but should not prevent the core workflow from functioning.

A robust implementation can provide a Python-generated fallback summary if the local LLM or structured-output mechanism fails.

For example:

```text
LLM available
     |
     v
Generate AI Summary

LLM unavailable/error
     |
     v
Generate Python Summary
```

The final decision remains independent of the summary-generation model.

This makes the workflow more resilient.

---

# 32. Error Handling Considerations

Potential runtime issues include:

### Ollama unavailable

If Ollama is not running or the model is missing:

```text
ollama list
```

and:

```text
ollama pull llama3.2:3b
```

should be checked.

### Streamlit installation issue

Deep Windows paths can cause installation failures.

Recommended project path:

```text
C:\AIInsurance
```

### Structured output issues

Small local models may occasionally struggle with strict structured output.

A fallback summary mechanism reduces the impact.

### Invalid documents

Documents that cannot be parsed should be treated carefully and should not silently be considered verified.

---

# 33. Security Considerations

Insurance information can contain sensitive personal and financial data.

A production implementation should include:

- Encryption at rest
- Encryption in transit
- Authentication
- Authorization
- Audit logging
- Document access controls
- Secure file storage
- Data retention policies
- PII masking
- Secure deletion
- Model access controls

The local Ollama architecture is useful for development because claim information does not need to be sent to a third-party LLM API.

---

# 34. Responsible AI

An insurance AI system should not make unsupported conclusions.

The fraud detector should therefore be described as:

```text
Fraud Risk Screening
```

rather than:

```text
Fraud Confirmation
```

Similarly, the LLM should not invent:

- Medical facts
- Accident details
- Policy clauses
- Customer information
- Fraud evidence

The claim summary prompt should explicitly instruct the model to use only supplied facts.

---

# 35. Explainability

Every decision should have a reason.

Examples:

### Rejection

```text
Required document is missing.
```

### Eligibility rejection

```text
Incident occurred after policy expiry.
```

### Human review

```text
Claim amount exceeds the configured automatic approval threshold.
```

### Approval

```text
Documents are complete, policy is eligible, and no high-risk indicator was detected.
```

This makes the application easier for a human reviewer to understand.

---

# 36. Agentic AI Characteristics

This project demonstrates several characteristics of an agentic AI system.

## State

The claim state is maintained across the workflow.

## Planning / Routing

The graph determines which path should execute.

## Tool-like Processing

Individual agents perform specialized tasks.

## Conditional Decisions

The decision router chooses the next node.

## Parallel Execution

Independent checks execute as parallel branches.

## Human Intervention

The workflow pauses when human approval is required.

## Resumption

The graph continues after the human decision.

---

# 37. Why LangGraph Instead of a Simple Chain?

A simple chain would look like:

```text
A -> B -> C -> D -> E
```

Every operation executes sequentially.

The insurance workflow contains independent operations:

```text
       Document
          |
Eligibility + Fraud
```

These checks do not necessarily depend on each other's output.

LangGraph can represent:

```text
             Document
                |
                |
Eligibility ----+----> Summary
                |
              Fraud
```

This makes LangGraph better suited for complex stateful workflows.

It also provides native support for conditional routing and Human-in-the-Loop interruptions.

---

# 38. Future Enhancements

The current project is a working educational prototype. A production-grade system could add:

### 38.1 RAG

Store policy documents in a vector database and retrieve relevant policy clauses.

Possible architecture:

```text
Policy PDF
   |
Chunking
   |
Embeddings
   |
Vector DB
   |
Retriever
   |
Claim Analysis
```

### 38.2 OCR

Add OCR for scanned documents.

Potential technologies:

- Tesseract
- AWS Textract
- Azure Document Intelligence
- Google Document AI

### 38.3 Advanced Fraud Models

Use historical claims data to train:

- Classification models
- Anomaly detection
- Graph-based fraud detection

### 38.4 Database

Store:

- Claims
- Policies
- Decisions
- Reviewer actions
- Audit history

### 38.5 Authentication

Add role-based access:

```text
Claimant
Reviewer
Manager
Administrator
```

### 38.6 Notification

Send notifications through:

- Email
- SMS
- Enterprise messaging systems

### 38.7 Production Monitoring

Monitor:

- Processing latency
- Approval rate
- Rejection rate
- Escalation rate
- Model errors
- False positives
- False negatives

---

# 39. Suggested Production Architecture

A production architecture could look like:

```text
                Web / Mobile
                     |
                     v
                API Gateway
                     |
                     v
             Claim Processing API
                     |
              +------+------+
              |             |
              v             v
         Document Store   Database
              |
              v
         LangGraph
              |
      +-------+-------+
      |       |       |
      v       v       v
    Docs   Eligibility Fraud
      |       |       |
      +-------+-------+
              |
              v
          RAG / LLM
              |
              v
       Decision Engine
          /       \
         /         \
   Auto Decision   Human Review
         |             |
         +------+------+
                |
                v
             Audit DB
```

---

# 40. Key Learning Outcomes

This project demonstrates practical understanding of:

- LangGraph
- StateGraph
- Graph nodes
- Graph edges
- Conditional edges
- Parallel workflow branches
- Interrupt/resume
- Human-in-the-Loop
- LangChain
- Ollama
- Local LLM deployment
- Pydantic
- Streamlit
- PDF processing
- Deterministic business rules
- AI-assisted summarization
- Agentic workflow design
- Responsible AI

---

# 41. Viva Questions and Answers

## Q1. Why did you use LangGraph?

LangGraph is suitable for stateful agent workflows where different agents perform independent tasks and where conditional routing and human intervention are required.

## Q2. Why are Document Verification, Eligibility, and Fraud Detection parallel?

They can be performed independently based on the claim input and documents. Parallel execution reduces unnecessary sequential dependency.

## Q3. Why not let the LLM decide whether a claim is approved?

Insurance approval is a business-critical decision. Deterministic rules provide more predictable and explainable behavior.

## Q4. What is Human-in-the-Loop?

It means the AI workflow pauses and waits for a human decision before continuing.

## Q5. How is Human-in-the-Loop implemented?

LangGraph's `interrupt()` pauses execution and stores the workflow state. A later resume command provides the human decision.

## Q6. What does the Fraud Detection Agent do?

It identifies configured risk indicators and assigns a screening risk level such as LOW, MEDIUM, or HIGH.

## Q7. Does the system prove fraud?

No. It only identifies potential risk indicators for further review.

## Q8. Why use Ollama?

Ollama allows the project to run an LLM locally without requiring a paid OpenAI API key.

## Q9. Why use Streamlit?

Streamlit provides a simple Python-based interface for demonstrating the complete workflow.

## Q10. What happens if a required document is missing?

The Document Verification Agent marks the claim as incomplete and the decision engine rejects it.

## Q11. What happens if a policy has expired?

The Eligibility Agent marks the claim as ineligible, resulting in rejection.

## Q12. What triggers human review?

Examples include high fraud risk and claims at or above the configured high-value threshold.

## Q13. Can the system be connected to a database?

Yes. A production implementation could store claims, policies, decisions, audit logs, and reviewer actions in a relational or NoSQL database.

## Q14. Can RAG be added?

Yes. Policy documents can be indexed into a vector database and retrieved when evaluating policy coverage.

## Q15. What is the biggest limitation of the current project?

It is an educational prototype using simplified rules and synthetic documents. A production system requires validated insurance rules, secure infrastructure, historical data, advanced fraud models, governance, and human oversight.

---

# 42. Project File Structure

The project contains:

```text
AI_Insurance_Claim_Processing_Agent_LOCAL/
│
├── app.py
├── graph.py
├── rag_engine.py
├── models.py
├── requirements.txt
├── README.md
├── PROJECT_CHECKLIST.md
├── SAMPLE_TEST_CASES.md
└── .gitignore
```

### app.py

Contains the Streamlit user interface.

### graph.py

Contains the LangGraph workflow.

### rag_engine.py

Contains document verification, eligibility, fraud detection, summary generation, and decision logic.

### models.py

Contains Pydantic models and graph state definitions.

### requirements.txt

Contains Python dependencies.

---

# 43. Conclusion

The AI Insurance Claim Processing Agent demonstrates how an insurance workflow can be converted into an agentic AI system using LangGraph.

The project successfully combines:

```text
Structured Input
       +
Document Processing
       +
Parallel Verification
       +
Rule-Based Screening
       +
LLM Summarization
       +
Conditional Routing
       +
Human Approval
```

The most important architectural decision is keeping the final business decision deterministic.

Instead of allowing the LLM to independently decide whether a claim should be approved, the application uses explicit Python rules for:

- Document completeness
- Eligibility
- Fraud risk
- High-value escalation
- Final routing

The LLM adds value where generative reasoning is appropriate: producing a human-readable claim summary.

LangGraph provides the orchestration layer that connects these components into a stateful workflow and supports Human-in-the-Loop processing.

The successful test case demonstrates the complete happy path:

```text
Claim Submitted
      ↓
Documents Verified
      ↓
Eligibility Confirmed
      ↓
Fraud Risk LOW
      ↓
Claim Summary Generated
      ↓
AUTO_APPROVE
      ↓
CLAIM APPROVED
```

The remaining test cases demonstrate rejection and human escalation paths.

Overall, the project provides a practical example of combining deterministic automation, local generative AI, graph-based orchestration, and human oversight into a reliable insurance claim-processing workflow.

---

# 44. Final Project Checklist

- [x] Streamlit application
- [x] LangGraph workflow
- [x] Document Verification Agent
- [x] Eligibility Check Agent
- [x] Fraud Detection Agent
- [x] Claim Summary Agent
- [x] Human Approval Agent
- [x] Parallel verification branches
- [x] Conditional edges
- [x] Human-in-the-Loop
- [x] Local Ollama LLM
- [x] PDF/TXT document support
- [x] Deterministic decision engine
- [x] Test cases
- [x] Auto approval
- [x] Rejection path
- [x] Human review path
- [x] Explainable decision reasons
- [x] Local Windows deployment

---

## Appendix A — Example End-to-End Flow

```text
                    CLAIM
                      |
                      v
              +---------------+
              | LangGraph     |
              | State         |
              +-------+-------+
                      |
        +-------------+-------------+
        |             |             |
        v             v             v
   Documents      Eligibility     Fraud
   Verification     Check        Detection
        |             |             |
        +-------------+-------------+
                      |
                      v
                Claim Summary
                      |
                      v
               Decision Engine
                      |
           +----------+----------+
           |          |          |
           v          v          v
       APPROVE      REJECT    HUMAN REVIEW
           |          |          |
           |          |          v
           |          |    Human Approval
           |          |          |
           +----------+----------+
                      |
                      v
                Final Status
```

---

## Appendix B — Example Decision Rules

```python
if missing_documents:
    decision = "REJECT"

elif not eligible:
    decision = "REJECT"

elif fraud_risk == "HIGH":
    decision = "HUMAN_REVIEW"

elif claim_amount >= 10_00_000:
    decision = "HUMAN_REVIEW"

else:
    decision = "AUTO_APPROVE"
```

This simple structure is intentional. Business-critical decisions should remain predictable and auditable.

---

## Appendix C — Sample Test Documents

Synthetic documents used for testing include:

```text
policy_document.pdf
identity_proof.pdf
repair_invoice.pdf
medical_bills.pdf
police_report.pdf
travel_ticket.pdf
```

These documents are for educational testing only and do not represent real insurance records.

---

**End of Project Report**
